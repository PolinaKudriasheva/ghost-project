# Ресурс на Ghost.js
